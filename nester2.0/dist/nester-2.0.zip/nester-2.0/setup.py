from distutils.core import setup

setup(
        name            = 'nester',
        version         = '2.0',
        py_modules      = ['nester'],
        auther          = 'JimmyLai',
        auther_email    = 'asd1947@126.com',
        url             = 'None',
        description     = 'A simple printer of nested lists',
      )
